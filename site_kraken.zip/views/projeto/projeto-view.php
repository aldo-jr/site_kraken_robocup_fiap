<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div class="container">
	<div class="jumbotron text-center">
		<h1><?= $this->title; ?></h1>
	</div>

	<div class="row">
		<div class="col-md-8">

		</div>

		<!--@TODO colocar modelo de noticias mais acessadas-->
		<?php //include("noticias_mais_acessadas.php"); ?>
	</div>
</div>

