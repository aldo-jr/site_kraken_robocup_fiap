<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div class="container">
  <div class="jumbotron text-center">
    <h1><?= $this->title; ?></h1>
  </div>

	<div class="row">
		<div class="col-md-8">
			<h2>O que é:</h2>
			<hr>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat, ducimus. Magni accusamus minima quibusdam enim ex ipsum,
				sit quae, hic alias tenetur aliquam, corporis reprehenderit asperiores mollitia quasi itaque dolorum, incidunt
				esse. Nulla aperiam, maxime, facere animi quo fugit quos deleniti earum excepturi dignissimos, placeat, sequi
				incidunt praesentium porro voluptate perferendis ab nemo cum molestias veritatis tempora ratione numquam. Ipsum
				expedita soluta aliquid architecto illo eligendi eaque sint ipsa? Ut, dolores, facere! Deleniti quasi id pariatur
				asperiores non velit repellat voluptate odio at corrupti eveniet quas aspernatur, nam quaerat expedita recusandae
				exercitationem adipisci inventore cupiditate architecto. Modi asperiores nesciunt quas minima debitis quisquam
				accusamus ratione pariatur possimus ipsam reprehenderit soluta adipisci, eveniet quaerat non praesentium dolores
				natus reiciendis hic, alias beatae accusantium. Laborum explicabo suscipit dolor consequatur rem delectus omnis
				magnam iusto voluptate amet? Dicta sunt omnis qui sequi sed odit, nulla vel quasi! Commodi tempore odit cupiditate
				consequuntur atque repudiandae, cumque adipisci at, qui consequatur saepe. Quidem ex, officiis facere! Aperiam
				maiores aspernatur numquam libero quas impedit qui velit quibusdam iure rem, deserunt nobis ratione sunt, soluta
				odio atque. Corporis id, reprehenderit explicabo architecto cupiditate voluptates totam, eveniet fugit fugiat
				perferendis accusamus omnis at, fuga cumque, velit culpa est.
			</p>
			<a href="<?php echo HOME_URI;?>/robocup/regulamento/">Veja o regulamento >></a>

		</div>

		<!--@TODO colocar modelo de noticias mais acessadas-->
		<?php //include("noticias_mais_acessadas.php"); ?>
	</div>
</div>

