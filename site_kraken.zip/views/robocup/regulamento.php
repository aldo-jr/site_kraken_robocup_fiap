<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div class="container">
	<div class="jumbotron text-center">
		<h1><?= $this->title; ?></h1>
	</div>

	<div class="row">
		<div class="col-md-8">
			<h2>Regulamento:</h2>
			<hr>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat, ducimus. Magni accusamus minima quibusdam enim ex ipsum,
				sit quae, hic alias tenetur aliquam, corporis reprehenderit asperiores mollitia quasi itaque dolorum, incidunt
				esse. Nulla aperiam, maxime, facere animi quo fugit quos deleniti earum excepturi dignissimos, placeat, sequi
				incidunt praesentium porro voluptate perferendis ab nemo cum molestias veritatis tempora ratione numquam. Ipsum
				expedita soluta aliquid <br>
				architecto illo eligendi eaque sint ipsa? Ut, dolores, facere! Deleniti quasi id pariatur
				asperiores non velit repellat voluptate odio at corrupti eveniet quas aspernatur, nam quaerat expedita recusandae
				exercitationem adipisci inventore cupiditate architecto. Modi asperiores nesciunt quas minima debitis quisquam
				accusamus ratione pariatur possimus ipsam reprehenderit soluta adipisci, eveniet quaerat non praesentium dolores
				natus reiciendis hic, alias beatae accusantium. Laborum explicabo suscipit dolor consequatur rem delectus omnis
				magnam iusto voluptate amet? Dicta sunt omnis qui sequi sed odit, nulla vel quasi! Commodi tempore odit cupiditate
				consequuntur atque repudiandae, cumque adipisci at, qui consequatur saepe. Quidem ex, officiis facere! Aperiam
				maiores aspernatur.
			</p>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero iusto magni culpa maxime assumenda, officiis porro suscipit nemo temporibus libero asperiores laborum, dolorem quisquam error molestiae, recusandae ab provident. Mollitia aliquid quidem soluta quisquam id possimus error repudiandae ullam minus nobis laudantium, cum omnis excepturi, expedita quia doloribus ea debitis earum, dignissimos quas. Saepe dolore architecto consequatur, perspiciatis deserunt, incidunt sed iusto ut beatae quaerat, illo porro distinctio voluptates nostrum odio excepturi qui nemo. Magni et omnis molestias, consequuntur quaerat quisquam maiores optio ullam ipsa itaque suscipit temporibus magnam quibusdam, exercitationem provident quae. Accusantium voluptatum, qui iusto repellendus fugiat delectus?
			</p>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit ex, commodi. Eaque eum totam omnis odio soluta beatae, laborum. Quaerat voluptas, exercitationem ea accusantium aliquam fuga dolore commodi autem placeat, nesciunt facere nostrum neque nulla ullam? Mollitia recusandae at eos nam magnam rerum quae iure necessitatibus. Ipsa vel iure nam ipsum dolor odio doloribus harum, expedita atque, placeat, voluptate laborum, ab possimus esse ducimus vitae animi. Eveniet vitae voluptatum vel impedit, repellendus asperiores distinctio consequuntur omnis incidunt facilis provident mollitia aliquam, laudantium nam quod facere similique. Est, id voluptatem dolorum aliquid voluptatum saepe inventore, ea, dolore tenetur eos vitae distinctio molestias iste cum nobis temporibus impedit doloribus. Atque soluta tenetur ab tempora vel, dolorem numquam maxime itaque libero, suscipit quis, tempore esse pariatur doloribus quos, eveniet dolor. Recusandae doloremque molestiae, eaque in similique vel laudantium minus, veritatis ipsam pariatur nulla rem quidem vitae cum cupiditate expedita aliquam consequatur voluptatibus hic ea voluptates dolore. Autem sapiente illo odit at vero voluptatum quibusdam, dignissimos doloremque impedit debitis eos incidunt, tenetur ullam neque nobis architecto eaque inventore ratione. Quidem consequatur sequi, consequuntur eligendi numquam vel dolorem voluptatum harum placeat officia adipisci ut possimus sunt officiis, repellat autem facilis in soluta architecto sint? Facere sapiente neque quod minus perferendis! Ipsam recusandae hic maxime blanditiis asperiores consectetur dolores, beatae odio aliquam nam accusamus illum dolorum, doloremque obcaecati facere ducimus nobis debitis! Incidunt temporibus labore eveniet reiciendis, accusantium totam ea odit adipisci explicabo placeat! Quia aspernatur odit ut non omnis esse possimus, dignissimos, deserunt illum velit sunt architecto accusamus ipsa, ab repellat tenetur optio, cumque vitae fugit doloremque doloribus ipsam! Necessitatibus recusandae aliquam animi iusto quidem fuga, voluptate nihil vel, eos maxime, cupiditate ipsam obcaecati voluptas repellendus labore? Neque quasi nostrum hic minima magni earum veritatis dolorum ullam soluta ea. Molestias laudantium repellendus modi voluptates, nam.
			</p>
			<a href="">Conheça nosso grupo >></a>

		</div>


	</div>
</div>

