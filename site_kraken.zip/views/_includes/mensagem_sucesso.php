<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div class="container">
  <div class="alert alert-success text-center" role="alert">
    <h4 class="alert-heading mb-4"><?= $this->texto_titulo; ?></h4>
    <?= $this->texto_sucesso; ?>
  </div>
</div>