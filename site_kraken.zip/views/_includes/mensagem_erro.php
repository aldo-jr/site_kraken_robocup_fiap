<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div class="container">

	<div class="alert alert-danger text-center" role="alert">
		<h4 class="alert-heading mb-4">Não foi possível enviar contato.</h4>
		<p>
			Desculpe, não foi possível enviar seu contato no momento. <br>
			Por favor, tente novamente mais tarde!
		</p>
	</div>
</div>