<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<script src="<?php echo HOME_URI; ?>/views/_js/jquery/jquery-3.2.1.min.js"></script>
<script src="<?php echo HOME_URI; ?>/views/_js/popper/popper.min.js"></script>
<script src="<?php echo HOME_URI; ?>/views/_js/bootstrap/bootstrap.min.js"></script>
<script src="<?php echo HOME_URI; ?>/views/_js/scripts.min.js"></script>

</body>
</html>
