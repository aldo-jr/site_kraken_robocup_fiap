<?php if ( ! defined('ABSPATH')) exit; ?>

<div class="container">

  <div class="jumbotron text-center">
    <h1>Painel Admin</h1>
  </div>

</div>