<?php
/**
 * Este arquivo não faz nada, apenas inclui os arquivos necessários
 */
 
// Config
require_once 'config.php';